<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

    <title>Nomor 3</title>
</head>
<body>
    <h1>Pesanan List</h1>
    <div>
        <table border="1">
            <tr>
                <th>No.</th>
                <th>No. Pesanan</th>
                <th>Tanggal</th>
                <th>Nama Supplier</th>
                <th>Nama Produk</th>
                <th>Total</th>
                <th>Option</th>
            </tr>
                @foreach ($pesanans as $item)
                <tr>
                    <td>{{ $item->id }}</td>
                    <td>{{ $item->no_pesanan }}</td>
                    <td>{{ $item->tanggal }}</td>
                    <td>{{ $item->nm_supplier }}</td>
                    <td>{{ $item->nm_produk }}</td>
                    <td>{{ $item->total }}</td>
                    <td>
                        <a href="/showPesanan/{{ $item->id }}" class="btn btn-warning btn-sm"><i class="fa fa-pencil"></i>Edit</a>
                        {{-- <a href="/deleteCategory/{{ $c->id }}" onclick="return confirm('Are you sure to delete this data?');" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>Delete</a> --}}
                    </td>
                </tr>
                @endforeach
            
        </table>
    </div>
</body>
</html>