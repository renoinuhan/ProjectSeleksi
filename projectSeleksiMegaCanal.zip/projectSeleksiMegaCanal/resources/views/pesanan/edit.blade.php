<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Soal 3</title>
</head>
<body>
    <h1>Edit Pesanan</h1>

    @if ($errors->any())
    <ul>
        @foreach ($errors->all() as $error)
        <li>
            {{ $error }}
        </li>
        @endforeach
    </ul>    
    @endif
    
    {{-- <form method="POST" action="{{ route('show.pesanan') }}"> --}}
    <form method="POST" action="">

        @csrf
        @method('post')

        <div class="form-group">
            <label for="no_pesanan">No. Pesanan</label>
            <input type="text" id="no_pesanan" name="no_pesanan" placeholder="Nomor Pesanan">
            {{-- <input type="text" id="no_pesanan" name="no_pesanan" placeholder="Nomor Pesanan" value="{{ $dataPesanan->no_pesanan }}"> --}}

        </div>

        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            {{-- <input type="date" id="tanggal" name="tanggal" class="form-control" value="{{ $dataPesanan->tanggal }}"> --}}
            <input type="date" id="tanggal" name="tanggal" class="form-control">

        </div>

        <div class="form-group">
            <label for="nm_supplier">Nama Supplier</label>
            {{-- <input type="text"  id="nm_supplier" name="nm_supplier" placeholder="Nama Supplier" value="{{ $dataPesanan->nm_supplier }}"> --}}
            <input type="text"  id="nm_supplier" name="nm_supplier" placeholder="Nama Supplier">

        </div>

        <div class="form-group">
            <label for="nm_produk">Nama Produk</label>
            {{-- <input type="text"  id="nm_produk" name="nm_produk" placeholder="Nama Produk" value="{{ $dataPesanan->nm_produk }}"> --}}
            <input type="text"  id="nm_produk" name="nm_produk" placeholder="Nama Produk">

        </div>

        <div class="form-group">
            <label for="total">Total</label>
            {{-- <input type="float" id="total" name="total" placeholder="Total" value="{{ $dataPesanan->total }}"> --}}
            <input type="float" id="total" name="total" placeholder="Total">

        </div>

        <div>
            <input type="submit" value="Simpan">
        </div>
    </form>
</body>
</html>