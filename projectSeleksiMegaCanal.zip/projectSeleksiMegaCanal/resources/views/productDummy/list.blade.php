@extends('layouts.app');
@section('content')
    <h1 class="text center">Product List</h1>
    <div class="card-deffault">
        <div class="card-header">
            Product
        </div>
        <div class="card-body">
            <ul class="list-group">
                @foreach ($idUniques as $unique)
                    <div class="col-md-3">
                        {{ $unique['id'] }}
                    </div>
                @endforeach
            </ul>
        </div>
    </div>
@endsection