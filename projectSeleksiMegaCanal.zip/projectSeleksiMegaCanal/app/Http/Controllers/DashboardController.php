<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http; //untuk ngambil data dari link
use App\Models\Pesanan;
use App\Models\ProductList;


class DashboardController extends Controller
{
    //Product
    public function showProductList(){
        $products = Http::get('https://dummyjson.com/products')->json();
        // $collection = collect($products);
        $collection = collect($products);
        // $uniqueID = $collection->unique('id');
        $uniqueId = $collection->unique('id');
        // $countUnique = $collection->countBy('id');

        // dd($uniqueId);  
        // dump($uniqueID);

        return view('productDummy.list', [
            'idUniques' => $uniqueId
        ]);

    }

    //Pesanan
    public function showListPesanan(){
        $pesanan = Pesanan::all();
        return view('pesanan.list', ['pesanans' => $pesanan]);
    }

    public function createList(){
        return view('pesanan.create');
    }

    public function storeList(Request $request){
        // dd($request);
        $data = $request->validate([
            'no_pesanan' => 'required',
            'tanggal' => 'required|date',
            'nm_supplier' => 'required',
            'nm_produk' => 'required',
            'total' => 'required|numeric'
        ]);

        $newPesanan = Pesanan::create($data);

        return redirect(route('pesanan.list'));
    }

    public function showPesanan(Pesanan $id){
        $dataPesanan = Pesanan::find($id);

        return view('pesanan.edit', compact('dataPesanan'));
    }
    public function editPesanan(Request $request, $id){
        $dataPesanan = Pesanan::find($id);
        $dataPesanan->update($request->all());

        return redirect()->route('pesanan.list')->with('success','Transaksi Berhasil Diupdate');
    }
}
