<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Product
Route::get('listProduct', [DashboardController::class, 'showProductList'])->name('product.list');


// Pesanan
Route::get('listPesanan', [DashboardController::class, 'showListPesanan'])->name('pesanan.list');
Route::get('pesanan/create', [DashboardController::class, 'createList'])->name('create.pesanan');
Route::post('pesanan', [DashboardController::class, 'storeList'])->name('store.pesanan');
Route::get('showPesanan/{id}', [DashboardController::class, 'showPesanan'])->name('show.pesanan');
Route::get('edit/{id}', [DashboardController::class, 'editPesanan'])->name('edit.pesanan');



