;
<?php $__env->startSection('content'); ?>
    <h1 class="text center">Product List</h1>
    <div class="card-deffault">
        <div class="card-header">
            Product
        </div>
        <div class="card-body">
            <ul class="list-group">
                <?php $__currentLoopData = $idUniques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <?php echo e($unique['id']); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectSeleksiMegaCanal\resources\views/productDummy/list.blade.php ENDPATH**/ ?>