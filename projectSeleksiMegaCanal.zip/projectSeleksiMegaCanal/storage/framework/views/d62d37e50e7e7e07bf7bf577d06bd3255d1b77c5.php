<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Soal 3</title>
</head>
<body>
    <h1>Create Pesanan</h1>

    <?php if($errors->any()): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php echo e($error); ?>

        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>    
    <?php endif; ?>
    
    <form method="POST" action="<?php echo e(route('store.pesanan')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>

        <div class="form-group">
            <label for="no_pesanan">No. Pesanan</label>
            <input type="text" id="no_pesanan" name="no_pesanan" placeholder="Nomor Pesanan">
        </div>

        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" id="tanggal" name="tanggal" class="form-control">
        </div>

        <div class="form-group">
            <label for="nm_supplier">Nama Supplier</label>
            <input type="text"  id="nm_supplier" name="nm_supplier" placeholder="Nama Supplier">
        </div>

        <div class="form-group">
            <label for="nm_produk">Nama Produk</label>
            <input type="text"  id="nm_produk" name="nm_produk" placeholder="Nama Produk">
        </div>

        <div class="form-group">
            <label for="total">Total</label>
            <input type="float" id="total" name="total" placeholder="Total">
        </div>

        <div>
            <input type="submit" value="Simpan">
        </div>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\projectSeleksiMegaCanal\resources\views/pesanan/create.blade.php ENDPATH**/ ?>