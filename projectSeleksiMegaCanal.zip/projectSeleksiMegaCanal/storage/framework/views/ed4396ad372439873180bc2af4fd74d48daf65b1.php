<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

    <title>Nomor 3</title>
</head>
<body>
    <h1>Pesanan List</h1>
    <div>
        <table border="1">
            <tr>
                <th>No.</th>
                <th>No. Pesanan</th>
                <th>Tanggal</th>
                <th>Nama Supplier</th>
                <th>Nama Produk</th>
                <th>Total</th>
                <th>Option</th>
            </tr>
                <?php $__currentLoopData = $pesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->no_pesanan); ?></td>
                    <td><?php echo e($item->tanggal); ?></td>
                    <td><?php echo e($item->nm_supplier); ?></td>
                    <td><?php echo e($item->nm_produk); ?></td>
                    <td><?php echo e($item->total); ?></td>
                    <td>
                        <a href="/showPesanan/<?php echo e($item->id); ?>" class="btn btn-warning btn-sm"><i class="fa fa-pencil"></i>Edit</a>
                        
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </table>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\projectSeleksiMegaCanal\resources\views/pesanan/list.blade.php ENDPATH**/ ?>